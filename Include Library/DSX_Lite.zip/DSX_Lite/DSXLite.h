//DSX-07 Lite Motor L293D
// By Ahul07
// 2020

#ifndef DSXLite_h
#define DSXLite_h
#include "Arduino.h"

class DSX_pinMotors {

  private:
      int dinamo1;
      int dinamo2;
      int dinamo3;
      int dinamo4;

  public:

    DSX_pinMotors(int motorA, int motorB, int motorC, int motorD);
    void pinMotors();
    void forward();
    void backward();
    void turnRight();
    void turnLeft();
    void stops();

};

#endif
